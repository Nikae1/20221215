
function serverCall(page){
	
	if(page == "1"){
	location.href = "http://192.168.0.82/shu-cream/Login.jsp";
	
	}
	else if(page == "2"){
	location.href = "http://192.168.0.82/shu-cream/Registration.jsp";
	
	}
	else{
	location.href = "http://192.168.0.82/shu-cream/"+page;
	}

}